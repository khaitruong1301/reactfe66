import React, { Component } from 'react'

export default class Content extends Component {
    render() {
        return (
            <div className="content bg-primary text-white display-4">
                Content
            </div>
        )
    }
}
