import React, { Component } from 'react'
import BTHeader from './BTHeader'
export default class BaiTapLayoutBootstrap extends Component {
    render() {
        return (
            <div className="container-fluid">
                <BTHeader />
                {/* <BTBody /> */}
                {/* <BTFooter /> */}
            </div>
        )
    }
}
